#Proof Of Concept
import sys
import csv
import matplotlib.pyplot as plt
import numpy as np
import pickle
import glob

from keras.layers import Input, Dense, Reshape, Dropout, LSTM, Bidirectional
from keras.layers import BatchNormalization, Activation, ZeroPadding2D
from keras.layers.advanced_activations import LeakyReLU
from keras.models import Sequential, Model
from keras.optimizers import Adam
from keras.utils import np_utils
from keras.utils import plot_model

class GAN():
    def __init__(self, rows):
        self.seq_length = rows
        self.seq_shape = (self.seq_length, 1)
        self.latent_dim = 1000
        self.disc_loss = []
        self.gen_loss =[]
        
        optimizer = Adam(0.0002, 0.5)

        # Build and compile the discriminator
        self.discriminator = self.build_discriminator()
        self.discriminator.compile(loss='binary_crossentropy', optimizer=optimizer, metrics=['accuracy'])

        # Build the generator
        self.generator = self.build_generator()

        # The generator takes noise as input and generates note sequences
        z = Input(shape=(self.latent_dim,))
        generated_seq = self.generator(z)

        # For the combined model we will only train the generator
        self.discriminator.trainable = True

        # The discriminator takes generated images as input and determines validity
        validity = self.discriminator(generated_seq)

        # The combined model  (stacked generator and discriminator)
        # Trains the generator to fool the discriminator
        self.combined = Model(z, validity)
        self.combined.compile(loss='binary_crossentropy', optimizer=optimizer)

    def build_discriminator(self):

        model = Sequential()
        model.add(LSTM(512, input_shape=self.seq_shape, return_sequences=True))
        model.add(Bidirectional(LSTM(512)))
        #Add another layer to the LSTM layer previous
        #Either explain a bidirectional LSTM or remove the above layer (I think remove it)
        model.add(Dense(512))
        model.add(LeakyReLU(alpha=0.2))
        model.add(Dense(256))
        model.add(LeakyReLU(alpha=0.2))
        model.add(Dense(1, activation='sigmoid'))
        model.summary()
        plot_model(model, to_file="discriminator.png", show_layer_names=True, show_shapes=True)
        seq = Input(shape=self.seq_shape)
        validity = model(seq)

        return Model(seq, validity)
      
    def build_generator(self):

        model = Sequential()
        model.add(Dense(256, input_dim=self.latent_dim))
        model.add(LeakyReLU(alpha=0.2))
        model.add(BatchNormalization(momentum=0.8))
        model.add(Dense(512))
        model.add(LeakyReLU(alpha=0.2))
        model.add(BatchNormalization(momentum=0.8))
        model.add(Dense(1024))
        model.add(LeakyReLU(alpha=0.2))
        model.add(BatchNormalization(momentum=0.8))
        model.add(Dense(np.prod(self.seq_shape), activation='tanh'))
        model.add(Reshape(self.seq_shape))
        model.summary()
        plot_model(model, to_file="generator.png", show_layer_names=True, show_shapes=True)
        noise = Input(shape=(self.latent_dim,))
        seq = model(noise)

        return Model(noise, seq)

    def train(self, epochs=200, sequence_length=15):
    
    #Pull all the data into memory as raw. This is better than constantly accessing the disk
        RawData = np.genfromtxt('VX_Results_clean_15_or_greater_calls_per_sample.csv', delimiter=',')
        samples = 100
    
    # Pull all the data into a 90,3000 array. Terminate anything after 90 calls
    # Normalize all so that they are between -1 and 1 
    # Randomly make up the epochs given number above
    # For simplicity just take the first 1000 samples which a cardinality of 15

    # Adversarial ground truths
        # The following will make a matrix of ones or zeros with the batch_size indicating the
        # length of the y column. (not sure what its backwards but this may be a matrix thing)
        real = np.ones((samples, 1))
        fake = np.zeros((samples, 1))

    # The batch size is statically defined as one as we want each sample to be used
    # in training the Discriminator
    # Load and convert the data
    #notes = get_notes()//
    #n_vocab = len(set(notes))
    #X_train, y_train = prepare_sequences(notes, n_vocab)    
    #Deceptively y_train is not seen anywhere else in the program.
    #The sequence here of 100 symbols per sample. The initial sequence will start off with 15
    #The prepare_sequence is also normalized to -1 to 1
        sample_batch = np.zeros(shape=(100,sequence_length,1), dtype=int)
                
        # Training the model
        for epoch in range(epochs):

            

            for sample in range(samples):
                for timestep in range(sequence_length-1):
                    sample_batch[sample,timestep,0] = RawData[sample,timestep]

  
            # Normalize input between -1 and 1
            #380 is the number of system calls however the actual last number is 547
            #although it was not found in the malware

            #network_input = (network_input - float(380)/2) / (float(380)/2)
    
            # So assuming that we have to have -1 to 1. 
            # We have a range of 0 to 547. This gives us 548 descrete values.
            # The half way mark would be 274
            # normalized = samples - 274. This gives a range of -274 to 273 
            # normalized = x / 274 ; and keeping the polairty sign 
            
            normalized = ((sample_batch - 274)/274)
            # Training the discriminator
            # Select a random batch of note sequences
            #idx = np.random.randint(0, X_train.shape[0], batch_size)

            #noise = np.random.choice(range(484), (batch_size, self.latent_dim))
            #noise = (noise-242)/242
            #the random.normal indicates a gaussian distribution
            noise = np.random.normal(0, 1, (samples, self.latent_dim))

            # Generate a batch of new note sequences
            gen_seqs = self.generator.predict(noise)
            
            #normalized = np.reshape(normalized, (100, sequence_length, 1))
            
            # Train the discriminator
            d_loss_real = self.discriminator.train_on_batch(normalized, real)
            d_loss_fake = self.discriminator.train_on_batch(gen_seqs, fake)
            d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)


            #  Training the Generator
            noise = np.random.normal(0, 1, (samples, self.latent_dim))

            # Train the generator (to have the discriminator label samples as real)
            g_loss = self.combined.train_on_batch(noise, real)

            # Print the progress and save into loss lists
            #if epoch % sample_interval == 0:
            print ("%d [D loss: %f, acc.: %.2f%%] [G loss: %f]" % (epoch, d_loss[0], 100*d_loss[1], g_loss))
            self.disc_loss.append(d_loss[0])
            self.gen_loss.append(g_loss)
        
        self.IsMalware()
        self.GenerateMalwareSysCalls()
        self.plot_loss()

    def IsMalware(self):
        #def IsMalware(self,Sample_Batch):
        #We need to inject a series of either Malware or legitimate samples here
        #I am expecting an array of classification probablity
        #The discriminator is trained on 'real' malWare
        print("IsMalWare/n")
        #'Fake' malware or legit software should no be classified as malWare
        #Over a Sample_Batch of 100-500 Samples of 'real' malware, 'fake' malware, and legitimate software
        #We should get our statistisical results

    def GenerateMalwareSysCalls(self):
        #def GenerateMalwareSysCalls(self, input_notes):
        #Important to note that this is show proof of concept
        print("GenerateMalwareSysCalls")
        #We would just look at a batch of them to show what could be done next
        #This could be interesting in that the calls would be defined but the rest
        #Could be left to the imagination
        # Get pitch names and store in a dictionary
        #notes = input_notes
        #pitchnames = sorted(set(item for item in notes))
        #int_to_note = dict((number, note) for number, note in enumerate(pitchnames))
        # Use random noise to generate sequences
        #    noise = np.random.normal(0, 1, (1, self.latent_dim))
        #    predictions = self.generator.predict(noise)
        
        #pred_notes = [x*242+242 for x in predictions[0]]
        #pred_notes = [int_to_note[int(x)] for x in pred_notes]
        
        #create_midi(pred_notes, 'gan_final')
        
    def plot_loss(self):
        plt.plot(self.disc_loss, c='red')
        plt.plot(self.gen_loss, c='blue')
        plt.title("GAN Loss per Epoch")
        plt.legend(['Discriminator', 'Generator'])
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.savefig('GAN_Loss_per_Epoch_final.png', transparent=True)
        plt.close()




if __name__ == '__main__':
  gan = GAN(rows=15)    
  gan.train(epochs=50, sequence_length=15)