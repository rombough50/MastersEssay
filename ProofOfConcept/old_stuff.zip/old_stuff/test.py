import csv
import pprint
import numpy as np
import matplotlib.pyplot as plt

RawData = np.genfromtxt('VX_Results_clean_15_or_greater_calls_per_sample.csv', dtype=int, delimiter=',')
epoch = 2


sample = np.ndarray(shape=(1,1), dtype=int)

real_seqs = RawData[epoch]
print (real_seqs[1:15])

sample1 = np.insert(sample, 0, real_seqs[1:15]).T

normalized = ((sample1 - 274)/274)


print (sample1)
print (normalized)

calls = np.unique(RawData)
print (calls[1:200])

unique, counts = np.unique(RawData,return_counts=True)
e = np.asarray((unique, counts)).T
print(e)
print (counts[1:300])
plt.plot(e[:, 0], e[:, 1])
plt.show()